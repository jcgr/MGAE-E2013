To run the demo:
	1. Open the "Demo" folder.
	2. Run the "PathFinding.exe" file.